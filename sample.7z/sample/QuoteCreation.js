const puppeteer = require('puppeteer');
const { expect } = require('chai');
const _ = require('lodash');
const xlsxFile = require('read-excel-file/node')
const randExp = require('randexp');
const globalVariables = _.pick(global, ['browser', 'expect']);

let partnerid, username, password, zipcode, addressLine1, program,territory,latitude,longitude,wildFireScore,tornadoScore,hailScore,Straight_line;
xlsxFile('./Testdata.xlsx').then((rows) => {
     console.log(rows[1][1]);
     console.table(rows);
     partnerid = rows[1][0];
     username = rows[1][1];
     password = rows[1][2];
     zipcode = rows[1][3];
     addressLine1 = rows[1][4];
     program = rows[1][5];
     territory = rows[1][6];
     latitude = rows[1][7];
     longitude = rows[1][8];
     wildFireScore = rows[1][9];
     tornadoScore = rows[1][10];
     hailScore = rows[1][11];
     Straight_line = rows[1][12];
     console.table(rows);

})
// puppeteer options
const opts = {
     headless: false,
     slowMo: 20,
     timeout: 900000,
     defaultViewport: null,
     args: ['--start-maximized']
};

before(function (done) {
     global.expect = expect;

     puppeteer
          .launch(opts)
          .then(async (browser) => {
               global.browser = browser;
               global.page = await browser.newPage();
               //await page.goto('https://int.mylioinsurance.com/');
               await page.goto('https://lioqa.oneshield.com/splash.html');
               // await page.goto('https://mylioinsurance.com');
               done();
          });

});

describe("Quote Creation", () => {


     it("Provide partner id username password and verify login working fine ", async () => {

          try {
               
               await page.waitForSelector('.main-header #employeePortal')
               await page.click('.main-header #employeePortal')
     
               //partnerid
               await page.waitForSelector("div input[osviewid='PAI_2_OT_310_OI_1_BI_1075_CI_6376001']", { timeout: 20000 })
               await page.type("div input[osviewid='PAI_2_OT_310_OI_1_BI_1075_CI_6376001']", partnerid)
               await page.waitForTimeout(1000)
     
               //username
               await page.waitForSelector("div input[osviewid='PAI_2_OT_310_OI_1_BI_1075_CI_8780402']")
               await page.type("div input[osviewid='PAI_2_OT_310_OI_1_BI_1075_CI_8780402']", username)
               await page.waitForTimeout(1000)
               //password
               await page.waitForSelector("div input[osviewid='PAI_2_OT_310_OI_1_BI_1075_CI_8780502']")
               await page.type("div input[osviewid='PAI_2_OT_310_OI_1_BI_1075_CI_8780502']", password)
               await page.waitForTimeout(1000)   // Click on the next button
     
               await page.waitForSelector("div span[osviewid='PAI_2_OT_310_OI_1_BI_1075_CI_16014848']")
               await page.click("div span[osviewid='PAI_2_OT_310_OI_1_BI_1075_CI_16014848']")
     
          } catch (error) {

          await page.screenshot({ path: './Screenshots/login.png' });

               
          }
          
     });

     it("Validate the New quote or producing agency Page ", async () => {

          //New quote     
          await page.waitForSelector("div span[osviewid='PAI_117002_OT_310_OI_1_BI_963946_CI_14967946']")
          await page.click("div span[osviewid='PAI_117002_OT_310_OI_1_BI_963946_CI_14967946']")
          await page.waitForTimeout(2000)
          //choose agency
          await page.waitForSelector("div span[osviewid='PAI_304805_OT_63_OI_20_BI_381805_RS']")
          await page.click("div span[osviewid='PAI_304805_OT_63_OI_20_BI_381805_RS']")
          await page.waitForTimeout(1000)

          //next button     
          await page.waitForSelector("div span[osviewid='PAI_304805_AB_702446']")
          await page.click("div span[osviewid='PAI_304805_AB_702446']")

          let name = new randExp(/[a-z]{6}/).gen();
          //Business name     
          await page.waitForSelector("div input[osviewid='PAI_1086048_OT_3380946_OI_1_BI_1129948_CI_16118148']")
          await page.click("div input[osviewid='PAI_1086048_OT_3380946_OI_1_BI_1129948_CI_16118148']")
          await page.type("div input[osviewid='PAI_1086048_OT_3380946_OI_1_BI_1129948_CI_16118148']", name)

          //doing business name
          await page.waitForSelector("div input[osviewid='PAI_1086048_OT_3380946_OI_1_BI_1129948_CI_16186848']")
          await page.type("div input[osviewid='PAI_1086048_OT_3380946_OI_1_BI_1129948_CI_16186848']", "Sample" + name)
          //zip code
          await page.waitForSelector("div input[osviewid='PAI_1086048_OT_3380946_OI_1_BI_1306748_CI_16118648']")
          await page.type("div input[osviewid='PAI_1086048_OT_3380946_OI_1_BI_1306748_CI_16118648']", zipcode)
          //Addreslin1
          await page.waitForSelector("div input[osviewid='PAI_1086048_OT_3380946_OI_1_BI_1306748_CI_16118748']")
          await page.type("div input[osviewid='PAI_1086048_OT_3380946_OI_1_BI_1306748_CI_16118748']", addressLine1)

          //search button
          await page.waitForSelector("div span[osviewid='PAI_1086048_OT_3380946_OI_1_BI_1131548_CI_16120748']")
          await page.click("div span[osviewid='PAI_1086048_OT_3380946_OI_1_BI_1131548_CI_16120748']")
          //search results

          // Exsisting Customer

          await page.waitForSelector("table tbody td div div[class='x-grid-item-container'] table tbody tr td:nth-child(1) div span");
          var count = await page.$$eval("table tbody td div div[class='x-grid-item-container'] table tbody tr td:nth-child(1) div span", ele => ele.length);
          console.log("COUNT", count)
          await page.waitForSelector("table tbody td div div[class='x-grid-item-container'] table tbody tr td:nth-child(1) div span");
          var linkTexts = await page.$$eval("table tbody td div div[class='x-grid-item-container'] table tbody tr td:nth-child(1) div span",
               elements => elements.map(item => item.textContent))
          console.log("#########", linkTexts)
          for (var i = 0; i <= linkTexts.length - 1; i++) {
               console.log("$$$", linkTexts[i]);
               if (linkTexts[i].includes(name)) {
                    await page.click("button span[osviewid='PAI_1086048_OT_3380746_OI_1_BI_1131648_AB_1182648']")

               }
               else {
                    //create a new cutomer button 

                    await page.waitForSelector("div span[osviewid='PAI_1086048_AB_1377448']")
                    await page.click("div span[osviewid='PAI_1086048_AB_1377448']")
                    await page.waitForTimeout(1000)

               }
          }

     });

     it("Validate Add a new customer page ", async () => {

          //corporation
          await page.waitForSelector("div[class='x-boundlist x-boundlist-floating x-layer x-boundlist-default x-border-box'] div ul li:nth-child(2)");
          await page.click("div[class='x-boundlist x-boundlist-floating x-layer x-boundlist-default x-border-box'] div ul li:nth-child(2)")
          //next button
          await page.waitForSelector("div a span[osviewid='PAI_1088748_AB_1377748']");
          await page.click("div a span[osviewid='PAI_1088748_AB_1377748']");

          //skip
          await page.waitForSelector("div a span[osviewid='PAI_1296548_AB_1460448']");
          await page.click("div a span[osviewid='PAI_1296548_AB_1460448']");

          //producer
          await page.waitForSelector("div[class='x-boundlist-list-ct x-unselectable x-scroller'] ul li:nth-child(10)");
          await page.click("div[class='x-boundlist-list-ct x-unselectable x-scroller'] ul li:nth-child(10)");

          var today = new Date();
          var date = (today.getMonth() + 1) + '/' + today.getDate() + '/' + today.getFullYear();
          console.log("DATE", date);
          await page.waitForTimeout(2000)

          // //effectivedate
          await page.waitForSelector("div input[osviewid='PAI_1442446_OT_5_OI_1_BI_1377746_CI_17767646']")
          await page.type("div input[osviewid='PAI_1442446_OT_5_OI_1_BI_1377746_CI_17767646']", date)
          await page.waitForTimeout(1000)
          //program HOA
          await page.waitForSelector("div input[osviewid='PAI_1442446_OT_5_OI_1_BI_1261648_CI_16685748']")
          await page.type("div input[osviewid='PAI_1442446_OT_5_OI_1_BI_1261648_CI_16685748']", program)
          await page.waitForTimeout(1000)

          //Next
          await page.waitForSelector("div span[osviewid='PAI_1442446_AB_1637146']")
          await page.click("div span[osviewid='PAI_1442446_AB_1637146']")


     });

     it("Validate Insured mailing information page ", async () => {

          //Quote Details
          // await page.waitForSelector("div input[osviewid='PAI_1418846_OT_2276904_OI_1_BI_1374748_CI_17270648']")
          // // await page.type("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div input","City of Los Angeles")
          // await page.focus("div input[osviewid='PAI_1418846_OT_2276904_OI_1_BI_1374748_CI_17270648']")
          // await page.waitForTimeout(1000)
          // await page.keyboard.down('Control');
          // await page.keyboard.press('A');
          // await page.keyboard.up('Control');
          // await page.keyboard.press('Backspace');
          // await page.waitForTimeout(1000)
          // await page.keyboard.type(territory)


          await page.waitForTimeout(500) 
          await page.waitForSelector("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div:nth-child(2)")          
          await page.click("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div:nth-child(2)")
          await page.waitForTimeout("5000")
          await page.click("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div:nth-child(2)")

          let territoryArray = await page.evaluate(() => {
            let territoryArray = [];
            const headerDom = document.querySelector("div[class='x-boundlist-list-ct x-unselectable x-scroller'] ul");
            console.log("headerDom => ", headerDom);
            headerDom.querySelectorAll('li').forEach(e => territoryArray.push(e.innerText))
            console.log("territoryArray", territoryArray);
            return territoryArray;
        });
        console.log("ARRAYDATA",territoryArray);
        let territoryIndex = territoryArray.indexOf("City of Los Angeles");
        territoryIndex++;
        console.log("INDEX",territoryIndex)
          await page.waitForTimeout(1000)
          await page.waitForSelector('div[class="x-boundlist-list-ct x-unselectable x-scroller"] ul li:nth-child('+territoryIndex+')')
          await page.click('div[class="x-boundlist-list-ct x-unselectable x-scroller"] ul li:nth-child('+territoryIndex+')')
          //  //Sav changes
          //  await page.waitForSelector("div a span[osviewid='PAI_1418846_AB_1661246']")
          //  await page.click("div a span[osviewid='PAI_1418846_AB_1661246']")
          //  await page.waitForTimeout(1000)

           //Nextred
           await page.waitForSelector("div a span[osviewid='PAI_1418846_AB_710946']")
           await page.click("div a span[osviewid='PAI_1418846_AB_710946']")
           await page.waitForTimeout(1000)

          // //underwriting question independent contractor
          //  await page.waitForSelector("input[osviewid='PAI_1413848_OT_3339756_OI_1_BI_1373648_CI_17264248_EC_2']")
          //  await page.click("input[osviewid='PAI_1413848_OT_3339756_OI_1_BI_1373648_CI_17264248_EC_2']")
          // //
          //  await page.waitForSelector("input[osviewid='PAI_1413848_OT_3339756_OI_1_BI_1373848_CI_17264448_EC_2']")
          //  await page.click("input[osviewid='PAI_1413848_OT_3339756_OI_1_BI_1373848_CI_17264448_EC_2']")

          //  //Nextred
          // await page.waitForSelector("div a span[osviewid='PAI_1413848_AB_710946']")
          // await page.click("div a span[osviewid='PAI_1413848_AB_710946']")

          //Location hazard
          //Latitude
          await page.waitForSelector("input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16229256']")
          await page.type("input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16229256']",latitude)
          await page.waitForTimeout(1000)
          //Longitude
          await page.waitForSelector("input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16229356']")
          await page.type("input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16229356']",longitude)
          await page.waitForTimeout(1000)

           //wild fild score
           await page.waitForSelector("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16229456']")
           // await page.type("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div input","City of Los Angeles")
           await page.focus("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16229456']")
           await page.waitForTimeout(1000)
           await page.keyboard.down('Control');
           await page.keyboard.press('A');
           await page.keyboard.up('Control');
           await page.keyboard.press('Backspace');
           await page.waitForTimeout(1000)
           await page.keyboard.type(wildFireScore)
 
               //Tornado score
               await page.waitForSelector("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16229556']")
               // await page.type("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div input","City of Los Angeles")
               await page.focus("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16229556']")
               await page.waitForTimeout(1000)
               await page.keyboard.down('Control');
               await page.keyboard.press('A');
               await page.keyboard.up('Control');
               await page.keyboard.press('Backspace');
               await page.waitForTimeout(1000)
               await page.keyboard.type(tornadoScore)
        
               //Hail score
          await page.waitForSelector("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16229656']")
          // await page.type("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div input","City of Los Angeles")
          await page.focus("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16229656']")
          await page.waitForTimeout(1000)
          await page.keyboard.down('Control');
          await page.keyboard.press('A');
          await page.keyboard.up('Control');
          await page.keyboard.press('Backspace');
          await page.waitForTimeout(1000)
          await page.keyboard.type(hailScore)

     //Straight-line score
     await page.waitForSelector("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16229756']")
     // await page.type("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div input","City of Los Angeles")
     await page.focus("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16229756']")
     await page.waitForTimeout(1000)
     await page.keyboard.down('Control');
     await page.keyboard.press('A');
     await page.keyboard.up('Control');
     await page.keyboard.press('Backspace');
     await page.waitForTimeout(1000)
     await page.keyboard.type(Straight_line)

     //free fire score
     await page.waitForSelector("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16229956']")
     // await page.type("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div input","City of Los Angeles")
     await page.focus("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16229956']")
     await page.waitForTimeout(1000)
     await page.keyboard.down('Control');
     await page.keyboard.press('A');
     await page.keyboard.up('Control');
     await page.keyboard.press('Backspace');
     await page.waitForTimeout(1000)
     await page.keyboard.type("No")
  

     //wind pool
     await page.waitForSelector("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16230056']")
     // await page.type("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div input","City of Los Angeles")
     await page.focus("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16230056")
     await page.waitForTimeout(1000)
     await page.keyboard.down('Control');
     await page.keyboard.press('A');
     await page.keyboard.up('Control');
     await page.keyboard.press('Backspace');
     await page.waitForTimeout(1000)
     await page.keyboard.type("Within Windpool Zone")

     
     //distance to cost
     // await page.waitForSelector("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16230156']")
     // // await page.type("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div input","City of Los Angeles")
     // await page.focus("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16230156")
     // await page.waitForTimeout(1000)
     // await page.keyboard.down('Control');
     // await page.keyboard.press('A');
     // await page.keyboard.up('Control');
     // await page.keyboard.press('Backspace');
     // await page.waitForTimeout(1000)
     // await page.keyboard.type("123")

     await page.waitForSelector("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16230156']")
     await page.type("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1135556_CI_16230156']","123")
     await page.waitForTimeout(1000)
     //Hurricane
     await page.waitForSelector("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1136556_CI_16230356']")
     await page.type("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1136556_CI_16230356']","12")
     await page.waitForTimeout(1000)

     //reinsurance
     await page.waitForSelector("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1136556_CI_16230456']")
     await page.type("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1136556_CI_16230456']","12")
     await page.waitForTimeout(1000)

     //cost of capital
     await page.waitForSelector("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1136556_CI_16230556']")
     await page.type("div input[osviewid='PAI_319615_OT_2191505_OI_1_BI_1136556_CI_16230556']","12")
     await page.waitForTimeout(1000)

           //Nextred
           await page.waitForSelector("div a span[osviewid='PAI_319615_AB_710946']")
           await page.click("div a span[osviewid='PAI_319615_AB_710946']")
           await page.waitForTimeout(1000)


     });

     it("Validate Building details page ", async () => {

          await page.waitForTimeout(500) 
          await page.waitForSelector("input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1138656_CI_16216256']")          
          await page.click("input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1138656_CI_16216256']")
          await page.waitForTimeout("5000")
          await page.click("input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1138656_CI_16216256']")

          let buildingClass = await page.evaluate(() => {
               let buildingClass = [];
               const headerDom = document.querySelector("div[class='x-boundlist-list-ct x-unselectable x-scroller'] ul");
               console.log("headerDom => ", headerDom);
               headerDom.querySelectorAll('li').forEach(e => buildingClass.push(e.innerText))
               console.log("buildingClass", buildingClass);
               return buildingClass;
           });
           console.log("ARRAYDATA",buildingClass);
           let buildingIndex = buildingClass.indexOf("Boat Storage and Moorage - In buildings");
           buildingIndex++;
           console.log("INDEX",buildingIndex)
             await page.waitForTimeout(1000)
             await page.waitForSelector('div[class="x-boundlist-list-ct x-unselectable x-scroller"] ul li:nth-child('+buildingIndex+')')
             await page.click('div[class="x-boundlist-list-ct x-unselectable x-scroller"] ul li:nth-child('+buildingIndex+')')
     
              //Protection class
     await page.waitForSelector("div input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1134856_CI_16216656']")
     // await page.type("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div input","City of Los Angeles")
     await page.focus("div input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1134856_CI_16216656")
     await page.waitForTimeout(1000)
     await page.keyboard.down('Control');
     await page.keyboard.press('A');
     await page.keyboard.up('Control');
     await page.keyboard.press('Backspace');
     await page.waitForTimeout(1000)
     await page.keyboard.type("2")
      
     //number of units
     await page.waitForSelector("div input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1134856_CI_16216756']")
     await page.type("div input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1134856_CI_16216756']","03")
     await page.waitForTimeout(1000)

      //year build
      await page.waitForSelector("div input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1134856_CI_16216556']")
      await page.type("div input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1134856_CI_16216556']","2015")
      await page.waitForTimeout(1000)

       //total sq feet
     await page.waitForSelector("div input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1134856_CI_16216856']")
     await page.type("div input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1134856_CI_16216856']","1200")
     await page.waitForTimeout(1000)
           //Roof type
     // await page.waitForTimeout(500) 
     // await page.waitForSelector("input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1134856_CI_16215756']")          
     // await page.click("input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1134856_CI_16215756']")
     // await page.waitForTimeout("5000")
     // await page.click("input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1134856_CI_16215756']")

                   await page.waitForSelector("div input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1134856_CI_16215756']")
                   // await page.type("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div input","City of Los Angeles")
                   await page.focus("div input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1134856_CI_16215756']")
                   await page.waitForTimeout(1000)
                   await page.keyboard.down('Control');
                   await page.keyboard.press('A');
                   await page.keyboard.up('Control');
                   await page.keyboard.press('Backspace');
                   await page.waitForTimeout(1000)
                   await page.keyboard.type("Concrete or clay tiles")
                  //BGI territoty  
                   await page.waitForSelector("div input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1138756_CI_16215856']")
                   // await page.type("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div input","City of Los Angeles")
                   await page.focus("div input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1138756_CI_16215856']")
                   await page.waitForTimeout(1000)
                   await page.keyboard.down('Control');
                   await page.keyboard.press('A');
                   await page.keyboard.up('Control');
                   await page.keyboard.press('Backspace');
                   await page.waitForTimeout(1000)
                   await page.keyboard.type("Balance of State")
                    
//Special territoty  
await page.waitForSelector("div input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1138756_CI_16216056']")
// await page.type("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div input","City of Los Angeles")
await page.focus("div input[osviewid='PAI_1088256_OT_2191305_OI_1_BI_1138756_CI_16216056']")
await page.waitForTimeout(1000)
await page.keyboard.down('Control');
await page.keyboard.press('A');
await page.keyboard.up('Control');
await page.keyboard.press('Backspace');
await page.waitForTimeout(1000)
await page.keyboard.type("Alameda")

 //Nextred
 await page.waitForSelector("div a span[osviewid='PAI_1088256_AB_710946']")
 await page.click("div a span[osviewid='PAI_1088256_AB_710946']")
 await page.waitForTimeout(1000)
 
 
       //amount of insurance
       await page.waitForSelector("div input[osviewid='PAI_1088356_OT_2191305_OI_1_BI_1134956_CI_16221656']")
       await page.type("div input[osviewid='PAI_1088356_OT_2191305_OI_1_BI_1134956_CI_16221656']","751")
       await page.waitForTimeout(1000)
          
        //Nextred
 await page.waitForSelector("div a span[osviewid='PAI_1088356_AB_710946']")
 await page.click("div a span[osviewid='PAI_1088356_AB_710946']")
 await page.waitForTimeout(1000)

 //Premises operation territory  
await page.waitForSelector("div input[osviewid='PAI_338615_OT_2184605_OI_1_BI_1362746_CI_16260056']")
// await page.type("table tbody tr:nth-child(2) td div div div:nth-child(2) div table tbody tr td:nth-child(2) div div div div div div div div div input","City of Los Angeles")
await page.focus("div input[osviewid='PAI_338615_OT_2184605_OI_1_BI_1362746_CI_16260056']")
await page.waitForTimeout(1000)
await page.keyboard.down('Control');
await page.keyboard.press('A');
await page.keyboard.up('Control');
await page.keyboard.press('Backspace');
await page.waitForTimeout(1000)
await page.keyboard.type("002")

 //Nextred
 await page.waitForSelector("div a span[osviewid='PAI_338615_AB_710946']")
 await page.click("div a span[osviewid='PAI_338615_AB_710946']")
 await page.waitForTimeout(1000)
 
       //number of units
       await page.waitForSelector("div input[osviewid='PAI_1089156_OT_2185405_OI_1_BI_1139256_CI_16240856']")
       await page.type("div input[osviewid='PAI_1089156_OT_2185405_OI_1_BI_1139256_CI_16240856']","03")
       await page.waitForTimeout(1000)
 
       //Nextred
 await page.waitForSelector("div a span[osviewid='PAI_1089156_AB_710946']")
 await page.click("div a span[osviewid='PAI_1089156_AB_710946']")
 await page.waitForTimeout(1000)

  //SummaryPage
  await page.waitForSelector("div a span[osviewid='PAI_1089156_AB_343105']")
  await page.click("div a span[osviewid='PAI_1089156_AB_343105']")
  await page.waitForTimeout(1000)
 
     });

     // it("Validate Policy details page ", async () => {

     //      await page.waitForSelector('.modal-open', { hidden: true });

     //      await page.waitForSelector('div > #policy\\.hasLosses > #policy\\.hasLosses\\_\\_BV\\_toggle\\_ > .d-flex > .text-right')
     //      await page.click('div > #policy\\.hasLosses > #policy\\.hasLosses\\_\\_BV\\_toggle\\_ > .d-flex > .text-right')

     //      await page.waitForSelector('div > #policy\\.hasLosses > .dropdown-menu > li:nth-child(2) > .dropdown-item')
     //      await page.click('div > #policy\\.hasLosses > .dropdown-menu > li:nth-child(2) > .dropdown-item')

     //      await page.waitForSelector('div > div > #policy\\.hasExisting > #policy\\.hasExisting\\_\\_BV\\_toggle\\_ > .d-flex')
     //      await page.click('div > div > #policy\\.hasExisting > #policy\\.hasExisting\\_\\_BV\\_toggle\\_ > .d-flex')

     //      await page.waitForSelector('div > #policy\\.hasExisting > .dropdown-menu > li:nth-child(1) > .dropdown-item')
     //      await page.click('div > #policy\\.hasExisting > .dropdown-menu > li:nth-child(1) > .dropdown-item')

     //      await page.waitForSelector('div > #policy\\.hasLapse > #policy\\.hasLapse\\_\\_BV\\_toggle\\_ > .d-flex > .flex-fill')
     //      await page.click('div > #policy\\.hasLapse > #policy\\.hasLapse\\_\\_BV\\_toggle\\_ > .d-flex > .flex-fill')

     //      await page.waitForSelector('div > #policy\\.hasLapse > .dropdown-menu > li:nth-child(1) > .dropdown-item')
     //      await page.click('div > #policy\\.hasLapse > .dropdown-menu > li:nth-child(1) > .dropdown-item')

     //      await page.waitForSelector('.h-100 #policy\\.expiringPremium')
     //      await page.type('.h-100 #policy\\.expiringPremium', '20000')

     //      await page.waitForSelector('div > div > #policy\\.hasLosses > #policy\\.hasLosses\\_\\_BV\\_toggle\\_ > .d-flex')
     //      await page.click('div > div > #policy\\.hasLosses > #policy\\.hasLosses\\_\\_BV\\_toggle\\_ > .d-flex')

     //      await page.waitForSelector('div > #policy\\.hasLosses > .dropdown-menu > li:nth-child(1) > .dropdown-item')
     //      await page.click('div > #policy\\.hasLosses > .dropdown-menu > li:nth-child(1) > .dropdown-item')

     //      await page.waitForSelector('.h-100 #policy\\.totalLosses')
     //      await page.type('.h-100 #policy\\.totalLosses', '2000')

     //      await page.waitForSelector('label[id^="\\_\\_BVID\\_\\_"][id$="\\_\\_value\\_"]', { timeout: 120000 })
     //      await page.click('label[id^="\\_\\_BVID\\_\\_"][id$="\\_\\_value\\_"]')

     //      await page.waitForSelector("div[class='b-calendar-grid-body'] div span[class='btn border-0 rounded-circle text-nowrap focus btn-outline-primary font-weight-bold']")
     //      await page.click("div[class='b-calendar-grid-body'] div span[class='btn border-0 rounded-circle text-nowrap focus btn-outline-primary font-weight-bold']")

     //      await page.waitForSelector('.quote-step > .vh-100 > .overflow-hidden > .text-center > .btn:nth-child(2)')
     //      await page.click('.quote-step > .vh-100 > .overflow-hidden > .text-center > .btn:nth-child(2)')

     // });

     // it(" Validate Buliding Types + Lables ", async () => {

     //      await page.waitForSelector('.toast.shown', { hidden: true });

     //      await page.waitForSelector('tbody > tr > td > .btn > span', { timeout: 120000 })
     //      await page.click('tbody > tr > td > .btn > span')

     //      await page.waitForSelector('.toast.shown', { hidden: true, timeout: 120000 });

     //      await page.waitForSelector('#miscOutdoor\\_\\_\\_BV\\_modal\\_body\\_');

     //      await page.waitForSelector('div > div > #locations\\.location-1\\.propertyClass_1 > #locations\\.location-1\\.propertyClass_1__BV_toggle_ > .d-flex', { timeout: 120000 })
     //      await page.click('div > div > #locations\\.location-1\\.propertyClass_1 > #locations\\.location-1\\.propertyClass_1__BV_toggle_ > .d-flex')


     //      await page.waitForSelector('div > #locations\\.location-1\\.propertyClass_1 > .dropdown-menu > li:nth-child(1) > .dropdown-item')
     //      await page.click('div > #locations\\.location-1\\.propertyClass_1 > .dropdown-menu > li:nth-child(1) > .dropdown-item')

     //      await page.waitForSelector('#locations\\.location-1\\.amtOfInsurance_1')
     //      await page.type('#locations\\.location-1\\.amtOfInsurance_1', '1000')

     //      await page.waitForSelector('.h-100 #locations\\.location-1\\.description_1')
     //      await page.type('.h-100 #locations\\.location-1\\.description_1', 'Puppeteer')

     //      await page.waitForSelector('.modal-dialog > #miscOutdoor\\_\\_\\_BV\\_modal\\_content\\_ > #miscOutdoor\\_\\_\\_BV\\_modal\\_footer\\_ > .w-100 > .btn')
     //      await page.click('.modal-dialog > #miscOutdoor___BV_modal_content_ > #miscOutdoor___BV_modal_footer_ > .w-100 > .btn')

     //      await page.waitForSelector('.toast.shown', { hidden: true });



     // });

     // it(" Validate Building Construction Details page ", async () => {

     //      await page.waitForSelector('.toast.shown', { hidden: true });

     //      await page.waitForSelector('.scroll-quote-panel > .mh-100 > .d-flex > .w-25 > .next-tab')
     //      await page.click('.scroll-quote-panel > .mh-100 > .d-flex > .w-25 > .next-tab')

     //      await page.waitForSelector('.w-75 > #buildingFields\\.bClass > #buildingFields\\.bClass__BV_toggle_ > .d-flex > .flex-fill')
     //      await page.click('.w-75 > #buildingFields\\.bClass > #buildingFields\\.bClass__BV_toggle_ > .d-flex > .flex-fill')

     //      await page.waitForSelector('.w-75 > #buildingFields\\.bClass > .dropdown-menu > li:nth-child(1) > .dropdown-item')
     //      await page.click('.w-75 > #buildingFields\\.bClass > .dropdown-menu > li:nth-child(1) > .dropdown-item')

     //      await page.waitForSelector('.w-100 > #buildingFields\\.roofType > #buildingFields\\.roofType__BV_toggle_ > .d-flex > .flex-fill')
     //      await page.click('.w-100 > #buildingFields\\.roofType > #buildingFields\\.roofType__BV_toggle_ > .d-flex > .flex-fill')

     //      await page.waitForSelector('.w-100 > #buildingFields\\.roofType > .dropdown-menu > li:nth-child(1) > .dropdown-item')
     //      await page.click('.w-100 > #buildingFields\\.roofType > .dropdown-menu > li:nth-child(1) > .dropdown-item')

     //      await page.waitForSelector('.h-100 #buildingFields\\.totalBldgSqFt')
     //      await page.type('.h-100 #buildingFields\\.totalBldgSqFt', '500')

     //      await page.waitForSelector('.h-100 #buildingFields\\.floorCt')
     //      await page.type('.h-100 #buildingFields\\.floorCt', '2')

     //      await page.waitForSelector('#buildingFields\\.yearBuilt')
     //      await page.type('#buildingFields\\.yearBuilt', '2000')

     // });


     // it("Validate Building Coverages page ", async () => {

     //      await page.waitForSelector('.scroll-quote-panel > .mh-100 > .d-flex > .w-25:nth-child(3) > a')
     //      await page.click('.scroll-quote-panel > .mh-100 > .d-flex > .w-25:nth-child(3) > a')

     //      await page.waitForSelector('.toast.shown', { hidden: true });

     //      await page.waitForSelector('.h-100 #buildingFields\\.buildingLimit')
     //      await page.type('.h-100 #buildingFields\\.buildingLimit', '1')

     //      await page.waitForSelector('.h-100 #buildingFields\\.bizPersonalProp')
     //      await page.type('.h-100 #buildingFields\\.bizPersonalProp', '25000')

     //      await page.waitForSelector('.h-100 #buildingFields\\.otherPersonalProp')
     //      await page.type('.h-100 #buildingFields\\.otherPersonalProp', '30000')

     //      await page.waitForSelector('.quote-step > .vh-100 > .overflow-hidden > .text-center > .btn:nth-child(2)')
     //      await page.click('.quote-step > .vh-100 > .overflow-hidden > .text-center > .btn:nth-child(2)')

     // });

     // it("Validate Blanket Coverages page ", async () => {

     //      await page.waitForSelector('.toast.shown', { hidden: true });

     //      // await page.waitForSelector('.mh-100 #addBuilding0')
     //      // await page.click('.mh-100 #addBuilding0')




     //      await page.waitForSelector('.quote-step > .vh-100 > .overflow-hidden > .text-center > .btn:nth-child(2)', { timeout: 120000 })
     //      await page.click('.quote-step > .vh-100 > .overflow-hidden > .text-center > .btn:nth-child(2)')

     // });

     // it("Validate Exposure Details page ", async () => {

     //      await page.waitForSelector('.toast.shown', { hidden: true });

     //      await page.waitForSelector('.h-100 #locations\\.location-1\\.unitCt')
     //      await page.type('.h-100 #locations\\.location-1\\.unitCt', '5')

     //      // await page.waitForSelector('.d-flex > .scroll-quote-panel > .mh-100 > .d-flex > .text-primary')
     //      // await page.click('.d-flex > .scroll-quote-panel > .mh-100 > .d-flex > .text-primary')

     //      // await page.waitForSelector('.h-100 #locations\\.location-2\\.unitCt')
     //      // await page.type('.h-100 #locations\\.location-2\\.unitCt', '4')

     //      await page.waitForSelector('.quote-step > .vh-100 > .overflow-hidden > .text-center > .btn:nth-child(2)')
     //      await page.click('.quote-step > .vh-100 > .overflow-hidden > .text-center > .btn:nth-child(2)')


     // });

     // it("Validate Quote Indication page ", async () => {

     //      await page.waitForSelector('.toast.shown', { hidden: true });

     //      await page.waitForSelector('div > .d-flex > .quote-panel > .text-center > .btn')
     //      await page.click('div > .d-flex > .quote-panel > .text-center > .btn')

     //      //await page.waitForSelector('.modal-open', { hidden: true });

     //      await page.waitForSelector('.quote-step > div > .pt-4 > a > .btn', { timeout: 120000 })
     //      await page.click('.quote-step > div > .pt-4 > a > .btn')

     // });

     // it("Validate Customize page ", async () => {

     //      await page.waitForSelector('.toast.shown', { hidden: true });

     //      await page.waitForSelector('.quote-step > .cust > .btn-toolbar > a:nth-child(2) > .btn')
     //      await page.click('.quote-step > .cust > .btn-toolbar > a:nth-child(2) > .btn')

     //      await page.waitForSelector('.accordion > .card:nth-child(3) > .card-header > .btn > .flex-fill')
     //      await page.click('.accordion > .card:nth-child(3) > .card-header > .btn > .flex-fill')

     //      await page.waitForSelector('.h-100 #buildingFields\\.elecUpdated')
     //      await page.type('.h-100 #buildingFields\\.elecUpdated', '2000')

     //      await page.waitForSelector('div > #buildingFields\\.polyPiping > #buildingFields\\.polyPiping__BV_toggle_ > .d-flex > .text-right')
     //      await page.click('div > #buildingFields\\.polyPiping > #buildingFields\\.polyPiping__BV_toggle_ > .d-flex > .text-right')

     //      await page.waitForSelector('div > #buildingFields\\.polyPiping > .dropdown-menu > li:nth-child(1) > .dropdown-item')
     //      await page.click('div > #buildingFields\\.polyPiping > .dropdown-menu > li:nth-child(1) > .dropdown-item')

     //      await page.waitForSelector('div > #buildingFields\\.alumWiring > #buildingFields\\.alumWiring__BV_toggle_ > .d-flex > .flex-fill')
     //      await page.click('div > #buildingFields\\.alumWiring > #buildingFields\\.alumWiring__BV_toggle_ > .d-flex > .flex-fill')

     //      await page.waitForSelector('div > #buildingFields\\.alumWiring > .dropdown-menu > li:nth-child(1) > .dropdown-item')
     //      await page.click('div > #buildingFields\\.alumWiring > .dropdown-menu > li:nth-child(1) > .dropdown-item')

     //      await page.waitForSelector('.h-100 #buildingFields\\.plumbingUpdated')
     //      await page.type('.h-100 #buildingFields\\.plumbingUpdated', '2000')

     //      await page.waitForSelector('.h-100 #buildingFields\\.roofUpdated')
     //      await page.type('.h-100 #buildingFields\\.roofUpdated', '2000')

     //      await page.waitForSelector('.quote-step > .cust > .btn-toolbar > a:nth-child(6) > .btn')
     //      await page.click('.quote-step > .cust > .btn-toolbar > a:nth-child(6) > .btn')

     //      await page.waitForSelector('.toast.shown', { hidden: true });

     //      await page.waitForSelector('div > .w-100 > #underwriting\\.contractorsCarryGL > #underwriting\\.contractorsCarryGL__BV_toggle_ > .d-flex')
     //      await page.click('div > .w-100 > #underwriting\\.contractorsCarryGL > #underwriting\\.contractorsCarryGL__BV_toggle_ > .d-flex')

     //      await page.waitForSelector('.w-100 > #underwriting\\.contractorsCarryGL > .dropdown-menu > li:nth-child(1) > .dropdown-item')
     //      await page.click('.w-100 > #underwriting\\.contractorsCarryGL > .dropdown-menu > li:nth-child(1) > .dropdown-item')

     //      await page.waitForSelector('.w-100 > #underwriting\\.secGuards > #underwriting\\.secGuards__BV_toggle_ > .d-flex > .text-right')
     //      await page.click('.w-100 > #underwriting\\.secGuards > #underwriting\\.secGuards__BV_toggle_ > .d-flex > .text-right')

     //      await page.waitForSelector('.w-100 > #underwriting\\.secGuards > .dropdown-menu > li:nth-child(2) > .dropdown-item')
     //      await page.click('.w-100 > #underwriting\\.secGuards > .dropdown-menu > li:nth-child(2) > .dropdown-item')

     //      await page.waitForSelector('.w-100 > #underwriting\\.unoccupiedUnitHeatRequired > #underwriting\\.unoccupiedUnitHeatRequired__BV_toggle_ > .d-flex > .text-right')
     //      await page.click('.w-100 > #underwriting\\.unoccupiedUnitHeatRequired > #underwriting\\.unoccupiedUnitHeatRequired__BV_toggle_ > .d-flex > .text-right')

     //      await page.waitForSelector('.w-100 > #underwriting\\.unoccupiedUnitHeatRequired > .dropdown-menu > li:nth-child(1) > .dropdown-item')
     //      await page.click('.w-100 > #underwriting\\.unoccupiedUnitHeatRequired > .dropdown-menu > li:nth-child(1) > .dropdown-item')

     //      await page.waitForSelector('.w-100 > #underwriting\\.ho6 > #underwriting\\.ho6__BV_toggle_ > .d-flex > .text-right')
     //      await page.click('.w-100 > #underwriting\\.ho6 > #underwriting\\.ho6__BV_toggle_ > .d-flex > .text-right')

     //      await page.waitForSelector('.w-100 > #underwriting\\.ho6 > .dropdown-menu > li:nth-child(1) > .dropdown-item')
     //      await page.click('.w-100 > #underwriting\\.ho6 > .dropdown-menu > li:nth-child(1) > .dropdown-item')

     //      await page.waitForSelector('.vh-100 > .quote-step > .cust > .text-center > .btn:nth-child(4)')
     //      await page.click('.vh-100 > .quote-step > .cust > .text-center > .btn:nth-child(4)')

     //      await page.waitForSelector('#simple > .modal-dialog > #simple___BV_modal_content_ > #simple___BV_modal_footer_ > .btn-primary')
     //      await page.click('#simple > .modal-dialog > #simple___BV_modal_content_ > #simple___BV_modal_footer_ > .btn-primary')

     // });

     // it("Validate Generate proposal Document ", async () => {

     //      await page.waitForSelector('.toast.shown', { hidden: true });

     //      await page.waitForSelector('.modal-open', { hidden: true, timeout: 120000 });

     //      await page.waitForSelector('.modal-open', { hidden: true, timeout: 120000 });

     //      await page.waitForSelector('.toast.shown', { hidden: true });

     //      await page.waitForSelector('.vh-100 > .quote-step > .cust > .text-center > .btn:nth-child(4)', { timeout: 120000 })
     //      await page.click('.vh-100 > .quote-step > .cust > .text-center > .btn:nth-child(4)')

     //      await page.screenshot({ path: './Screenshots/CondoPackageQuoteNumber.png' });

     //      await page.waitForSelector('.toast.shown', { hidden: true });

     //      await page.waitForSelector('.toast.shown', { hidden: true });

     //      await page.waitForSelector('.toast.shown', { hidden: true });

     //      await page.waitForSelector('#proposal___BV_modal_content_ > #proposal___BV_modal_body_ > .d-flex > div > .btn:nth-child(2)', { timeout: 120000 })
     //      await page.click('#proposal___BV_modal_content_ > #proposal___BV_modal_body_ > .d-flex > div > .btn:nth-child(2)')

     //      await page.waitForSelector('.toast.shown', { hidden: true });

     //      await page.waitForSelector('#proposal___BV_modal_content_ > #proposal___BV_modal_body_ > .d-flex > div > .btn:nth-child(4)', { timeout: 120000 })
     //      await page.click('#proposal___BV_modal_content_ > #proposal___BV_modal_body_ > .d-flex > div > .btn:nth-child(4)')

     // });

     // it("Validate Bind Quote", async () => {


     //      await page.waitForSelector('.modal-content', { hidden: true });

     //      await page.waitForSelector('.quote-step > .cust > .text-center > a > .btn')
     //      await page.click('.quote-step > .cust > .text-center > a > .btn')


     //      await page.waitForSelector('.h-100 > div > div > .custom-control > .custom-control-input')
     //      await page.click('.h-100 > div > div > .custom-control > .custom-control-input')

     //      await page.waitForSelector('.h-100 #bindQuote\\.printedName')
     //      await page.type('.h-100 #bindQuote\\.printedName', 'Puppeteer')

     //      await page.waitForSelector('.d-flex > .p-3 > .text-left:nth-child(2) > span > .btn')
     //      await page.click('.d-flex > .p-3 > .text-left:nth-child(2) > span > .btn')

     //      await page.waitForSelector('div > .drop-zone > .text-center > label > a')
     //      await page.click('div > .drop-zone > .text-center > label > a')

     //      await page.waitForSelector('input[id^="bindQuote"][id$="description"]', { timeout: 120000 })
     //      await page.type('input[id^="bindQuote"][id$="description"]', 'Puppeteer')

     //      await page.waitForSelector('.modal-dialog > #bindQuoteAttachments___BV_modal_content_ > #bindQuoteAttachments___BV_modal_footer_ > .w-100 > .btn-primary')
     //      await page.click('.modal-dialog > #bindQuoteAttachments___BV_modal_content_ > #bindQuoteAttachments___BV_modal_footer_ > .w-100 > .btn-primary')

     //      await page.waitForSelector('.modal-content', { hidden: true });

     //      await page.waitForSelector('.d-flex > .p-3 > .text-left:nth-child(3) > span > .btn', { timeout: 120000 })
     //      await page.click('.d-flex > .p-3 > .text-left:nth-child(3) > span > .btn')

     //      await page.waitForSelector('div > .drop-zone > .text-center > label > a')
     //      await page.click('div > .drop-zone > .text-center > label > a')

     //      await page.waitForSelector('input[id^="bindQuote"][id$="description"]', { timeout: 120000 })
     //      await page.type('input[id^="bindQuote"][id$="description"]', 'Puppeteer')

     //      await page.waitForSelector('.modal-dialog > #bindQuoteAttachments___BV_modal_content_ > #bindQuoteAttachments___BV_modal_footer_ > .w-100 > .btn-primary')
     //      await page.click('.modal-dialog > #bindQuoteAttachments___BV_modal_content_ > #bindQuoteAttachments___BV_modal_footer_ > .w-100 > .btn-primary')

     //      await page.waitForSelector('.modal-open', { hidden: true });
     // });

     // it("Validate Bind And Generate Policy", async () => {


     //      await page.waitForSelector('.vh-100 > .quote-step > .quote-bind > .text-center > .btn:nth-child(2)')
     //      await page.click('.vh-100 > .quote-step > .quote-bind > .text-center > .btn:nth-child(2)')

     //      await page.waitForSelector('.modal-open', { hidden: true, timeout: 120000 });

     //      await page.waitForSelector('.quote-step > div > .d-flex > .detail > .mb-5:nth-child(2)')
     //      await page.click('.quote-step > div > .d-flex > .detail > .mb-5:nth-child(2)')

     //      await page.screenshot({ path: './Screenshots/CondoPackagePolicyissue.png' });

     // });

})

after(function () {
     // browser.close();

     global.browser = globalVariables.browser;
     global.expect = globalVariables.expect;
});
