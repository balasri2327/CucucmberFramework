const puppeteer = require('puppeteer');
(async () => {
const browser = await puppeteer.launch();
const page = await browser.newPage();
await page.goto('https://qa.mylioinsurance.com/');
await page.screenshot({path: 'Screenshots1.png'});
await browser.close();
})();