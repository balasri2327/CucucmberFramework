const puppeteer = require('puppeteer');
const { expect } = require('chai');
const _ = require('lodash');
const globalVariables = _.pick(global, ['browser', 'expect']);

// puppeteer options

const opts = {
    headless: false,
    slowMo: 20,
    timeout: 900000,
    defaultViewport: null,
    args: ['--start-maximized']
};

before(function (done) {
    global.expect = expect;

    puppeteer
        .launch(opts)
        .then(async (browser) => {
            global.browser = browser;
            global.page = await browser.newPage();
           //  await page.goto('https://int.mylioinsurance.com/');
            // await page.goto('https://mylioinsurance.com/');
           await page.goto('https://qa.mylioinsurance.com/');
            done();
        });
});

describe("HOA GL flow", () => {


    it("Provide username password and verify login working fine ", async () => {

        await page.waitForSelector('#idp-discovery-username')
        await page.type("#idp-discovery-username", "producerc@lioinsurance.com"); //Enter Username........

        await page.evaluate(() => {
            document.querySelector('#idp-discovery-submit').click();    // Click on the next button
        });

        await page.waitForSelector('#okta-signin-password')//Enter Password.....
        await page.type("#okta-signin-password", "Lio2020!");

        await page.evaluate(() => {
            document.querySelector('#okta-signin-submit').click(); //Click to login button..
        });
        await page.waitForSelector('.dropdown-menu').then(() => console.log('Redirected to Home Page'));
        //await page.screenshot({path: 'Get Scope.png'});

        await page.evaluate(async() => {
            await new Promise(function(resolve) { 
                   setTimeout(resolve, 1000)
            });
        });


        let selector = 'a';     // Click on the get a quote link  
        await page.$$eval(selector, anchors => {
            anchors.map(anchor => {
                if (anchor.textContent == 'get a quote') {
                    anchor.click();
                    return
                }
            })
        });

    });

    it("Validate the Scope Page ", async () => {

        await page.waitForSelector('#scope\\.jurisdiction > #scope\\.jurisdiction__BV_toggle_')
        await page.click('#scope\\.jurisdiction > #scope\\.jurisdiction__BV_toggle_')

        await page.waitForSelector('div > #scope\\.jurisdiction > .dropdown-menu > li:nth-child(' + 1 + ') > .dropdown-item')

        let JurisdictionArray = await page.evaluate(() => {
            let JurisdictionArray = [];
            const headerDom = document.querySelector('#scope\\.jurisdiction > ul');
            console.log("headerDom => ", headerDom);
            headerDom.querySelectorAll('li').forEach(e => JurisdictionArray.push(e.innerText))
            console.log("JurisdictionArray", JurisdictionArray);
            return JurisdictionArray;
        });

        let scount=JurisdictionArray.length
        expect(scount).to.equal(3);
        expect(JurisdictionArray).to.contain('New Jersey', 'California', 'Texas')

        let californiaIndex = JurisdictionArray.indexOf("California");
        californiaIndex++;

        await page.waitForSelector('div > #scope\\.jurisdiction > .dropdown-menu > li:nth-child(' + californiaIndex + ') > .dropdown-item')
        await page.click('div > #scope\\.jurisdiction > .dropdown-menu > li:nth-child(' + californiaIndex + ') > .dropdown-item')

        await page.waitForSelector('div > #scope\\.product > #scope\\.product__BV_toggle_ > .d-flex > .flex-fill')
        await page.click('div > #scope\\.product > #scope\\.product__BV_toggle_ > .d-flex > .flex-fill')

        await page.waitForSelector('div > #scope\\.product > .dropdown-menu > li:nth-child(' + 1 + ') > .dropdown-item');

        let productArray = await page.evaluate(() => {
            let productArray = [];
            const headerDom = document.querySelector('#scope\\.product > ul');
            console.log("headerDom => ", headerDom);
            headerDom.querySelectorAll('li').forEach(e => productArray.push(e.innerText.trim()))
            console.log("productArray", productArray);
            return productArray;
        });

        let pcount=productArray.length
        expect(pcount).to.equal(2);
        expect(productArray).to.contain('Condominium Association', 'Homeowners (Townhome) Association (HOA)')

        let productIndex = productArray.indexOf("Homeowners (Townhome) Association (HOA)");
        productIndex++;

        await page.click('div > #scope\\.product > .dropdown-menu > li:nth-child(' + productIndex + ') > .dropdown-item')

        await page.waitForSelector('div > #scope\\.program > #scope\\.program__BV_toggle_ > .d-flex > .flex-fill')
        await page.click('div > #scope\\.program > #scope\\.program__BV_toggle_ > .d-flex > .flex-fill')

        await page.waitForSelector('div > #scope\\.program > .dropdown-menu > li:nth-child(1) > .dropdown-item')

        let packageArray = await page.evaluate(() => {
            let packageArray = [];
            const headerDom = document.querySelector('#scope\\.program > ul');
            console.log("headerDom => ", headerDom);
            headerDom.querySelectorAll('li').forEach(e => packageArray.push(e.innerText.trim()))
            console.log("packageArray", packageArray);
            return packageArray;
        });

        let ocount=packageArray.length
        expect(ocount).to.equal(2);
        expect(packageArray).to.contain('General Liability', 'Commercial Package Policy')

        let packageIndex = packageArray.indexOf("General Liability");
        packageIndex++;

        await page.click('div > #scope\\.program > .dropdown-menu > li:nth-child(' + packageIndex + ') > .dropdown-item')

        await page.waitForSelector('.vh-100 > .quote-step > .quote-scope > .text-center > .btn:nth-child(2)');
        await page.click('.vh-100 > .quote-step > .quote-scope > .text-center > .btn:nth-child(2)')

    });

    it("Validate Condo package eligibility Questions page ", async () => {

        await page.waitForSelector('input[id^="\\_\\_BVID\\_\\_"][id$="option\\_1"]');
        await page.waitForSelector(".quote-panel ul li");
        await page.click('input[id^="\\_\\_BVID\\_\\_"][id$="option\\_1"]');

        await page.waitForSelector('.vh-100 > .quote-step > div > .text-center > .btn:nth-child(2)')
        await page.click('.vh-100 > .quote-step > div > .text-center > .btn:nth-child(2)')

    });

    it("Validate Insured mailing information page ", async () => {


        await page.waitForSelector('.h-100 #insured\\.accountName')
        await page.type('.h-100 #insured\\.accountName', 'Puppeteer')

        await page.waitForSelector('.h-100 #insured\\.careOf')
        await page.type('.h-100 #insured\\.careOf', 'DemoPuppeteer')

        await page.waitForSelector('.h-100 #insured\\.email')
        await page.type('.h-100 #insured\\.email', 'DemoPuppeteer@puppteer.com')

        await page.waitForSelector('input[id^="input-"]')
        await page.type('input[id^="input-"]', '123');

        await page.waitForSelector('.v-menu__content > *  .v-list-item__title')
        await page.click('.v-menu__content > *  .v-list-item__title')

        await page.waitForSelector('.h-100 #insured\\.addressLine2')
        await page.type('.h-100 #insured\\.addressLine2', 'Puppeteer')

        await page.waitForSelector('.vh-100 > .quote-step > div > .text-center > .btn:nth-child(2)')
        await page.click('.vh-100 > .quote-step > div > .text-center > .btn:nth-child(2)')

    });

    it("Validate Insured Location page ", async () => {

        await page.waitForSelector('.modal-open', { hidden: true });

        await page.waitForSelector('.d-flex > .quote-panel > .mb-4 > .m-3 > .custom-control-label')
        await page.click('.d-flex > .quote-panel > .mb-4 > .m-3 > .custom-control-label')

        // await page.waitForSelector('.d-flex > .quote-panel > .mb-4 > .mr-4 > .btn')
        // await page.click('.d-flex > .quote-panel > .mb-4 > .mr-4 > .btn')

        //   await page.waitForSelector('.v-input #input-217')
        //   await page.type('.v-input #input-217', '111')

        //   await page.waitForSelector('.v-menu__content > #list-217 > #list-item-224-0 > .v-list-item__content > .v-list-item__title')
        //   await page.click('.v-menu__content > #list-217 > #list-item-224-0 > .v-list-item__content > .v-list-item__title')

        await page.waitForSelector('.vh-100 > .quote-step > .add-location > .text-center > .btn:nth-child(2)')
        await page.click('.vh-100 > .quote-step > .add-location > .text-center > .btn:nth-child(2)')


    });

    it("Validate Policy details page ", async () => {

        await page.waitForSelector('.modal-open', { hidden: true });

        await page.waitForSelector('div > #policy\\.hasLosses > #policy\\.hasLosses__BV_toggle_ > .d-flex > .text-right')
        await page.click('div > #policy\\.hasLosses > #policy\\.hasLosses__BV_toggle_ > .d-flex > .text-right')

        await page.waitForSelector('div > #policy\\.hasLosses > .dropdown-menu > li:nth-child(2) > .dropdown-item')
        await page.click('div > #policy\\.hasLosses > .dropdown-menu > li:nth-child(2) > .dropdown-item')

        await page.waitForSelector('.quote-step > .vh-100 > .overflow-hidden > .text-center > .btn:nth-child(2)')
        await page.click('.quote-step > .vh-100 > .overflow-hidden > .text-center > .btn:nth-child(2)')

        //   await page.waitForSelector('.h-100 #policy\\.hasExisting__BV_toggle_')
        //   await page.click('.h-100 #policy\\.hasExisting__BV_toggle_')

        //   await page.waitForSelector('div > #policy\\.hasExisting > #policy\\.hasExisting__BV_toggle_ > .d-flex > .text-right')
        //   await page.click('div > #policy\\.hasExisting > #policy\\.hasExisting__BV_toggle_ > .d-flex > .text-right')

        //   await page.waitForSelector('.h-100 #policy\\.hasExisting__BV_toggle_')
        //   await page.click('.h-100 #policy\\.hasExisting__BV_toggle_')

        //   await page.waitForSelector('div > #policy\\.hasExisting > .dropdown-menu > li:nth-child(1) > .dropdown-item')
        //   await page.click('div > #policy\\.hasExisting > .dropdown-menu > li:nth-child(1) > .dropdown-item')

        //   await page.waitForSelector('.h-100 #\\__BVID__326__outer_')
        //   await page.click('.h-100 #\\__BVID__326__outer_')

        //   await page.waitForSelector('#\\__BVID__328__calendar-grid_ > .b-calendar-grid-body > .row > #\\__BVID__328__cell-2021-05-31_ > .btn')
        //   await page.click('#\\__BVID__328__calendar-grid_ > .b-calendar-grid-body > .row > #\\__BVID__328__cell-2021-05-31_ > .btn')

        //   await page.waitForSelector('div > #policy\\.hasLapse > #policy\\.hasLapse__BV_toggle_ > .d-flex > .flex-fill')
        //   await page.click('div > #policy\\.hasLapse > #policy\\.hasLapse__BV_toggle_ > .d-flex > .flex-fill')

        //   await page.waitForSelector('div > #policy\\.hasLapse > .dropdown-menu > li:nth-child(1) > .dropdown-item')
        //   await page.click('div > #policy\\.hasLapse > .dropdown-menu > li:nth-child(1) > .dropdown-item')

        //   await page.waitForSelector('.h-100 #policy\\.expiringPremium')
        //   await page.type('.h-100 #policy\\.expiringPremium', '751')

        //   await page.waitForSelector('div > #policy\\.hasLosses > #policy\\.hasLosses__BV_toggle_ > .d-flex > .text-right')
        //   await page.click('div > #policy\\.hasLosses > #policy\\.hasLosses__BV_toggle_ > .d-flex > .text-right')

        //   await page.waitForSelector('div > #policy\\.hasLosses > .dropdown-menu > li:nth-child(2) > .dropdown-item')
        //   await page.click('div > #policy\\.hasLosses > .dropdown-menu > li:nth-child(2) > .dropdown-item')

        //   await page.waitForSelector('.quote-step > .vh-100 > .overflow-hidden > .text-center > .btn:nth-child(2)')
        //   await page.click('.quote-step > .vh-100 > .overflow-hidden > .text-center > .btn:nth-child(2)')

    });

    it("Validate Exposure Details page ", async () => {

        await page.waitForSelector('.toast.shown', { hidden: true });

        await page.waitForSelector('.h-100 #locations\\.location-1\\.unitCtHOA')
        await page.type('.h-100 #locations\\.location-1\\.unitCtHOA', '5')

        //   await page.waitForSelector('.d-flex > .scroll-quote-panel > .mh-100 > .d-flex > .text-primary')
        //   await page.click('.d-flex > .scroll-quote-panel > .mh-100 > .d-flex > .text-primary')

        //   await page.waitForSelector('.h-100 #locations\\.location-2\\.unitCt')
        //   await page.type('.h-100 #locations\\.location-2\\.unitCt', '4')

        await page.waitForSelector('.quote-step > .vh-100 > .overflow-hidden > .text-center > .btn:nth-child(2)')
        await page.click('.quote-step > .vh-100 > .overflow-hidden > .text-center > .btn:nth-child(2)')

    });

    it("Validate Quote Indication page ", async () => {

        await page.waitForSelector('.toast.shown', { hidden: true });

        await page.waitForSelector('div > .d-flex > .quote-panel > .text-center > .btn')
        await page.click('div > .d-flex > .quote-panel > .text-center > .btn')

        //await page.waitForSelector('.modal-open', { hidden: true });

        // await page.screenshot({path: './Screenshots/HOAGlQuoteNumber.png'});

        await page.waitForSelector('.quote-step > div > .pt-4 > a > .btn', { timeout: 120000 })
        await page.click('.quote-step > div > .pt-4 > a > .btn')


    });

    it("Validate Customize page ", async () => {

        await page.waitForSelector('.toast.shown', { hidden: true });

        await page.waitForSelector('.quote-step > .cust > .btn-toolbar > a:nth-child(6) > .btn')
        await page.click('.quote-step > .cust > .btn-toolbar > a:nth-child(6) > .btn')

        await page.waitForSelector('div > .w-100 > #underwriting\\.contractorsCarryGL > #underwriting\\.contractorsCarryGL__BV_toggle_ > .d-flex')
        await page.click('div > .w-100 > #underwriting\\.contractorsCarryGL > #underwriting\\.contractorsCarryGL__BV_toggle_ > .d-flex')

        await page.waitForSelector('.w-100 > #underwriting\\.contractorsCarryGL > .dropdown-menu > li:nth-child(1) > .dropdown-item')
        await page.click('.w-100 > #underwriting\\.contractorsCarryGL > .dropdown-menu > li:nth-child(1) > .dropdown-item')

        await page.waitForSelector('.w-100 > #underwriting\\.secGuards > #underwriting\\.secGuards__BV_toggle_ > .d-flex > .text-right')
        await page.click('.w-100 > #underwriting\\.secGuards > #underwriting\\.secGuards__BV_toggle_ > .d-flex > .text-right')

        await page.waitForSelector('.w-100 > #underwriting\\.secGuards > .dropdown-menu > li:nth-child(2) > .dropdown-item')
        await page.click('.w-100 > #underwriting\\.secGuards > .dropdown-menu > li:nth-child(2) > .dropdown-item')

        await page.waitForSelector('.vh-100 > .quote-step > .cust > .text-center > .btn:nth-child(4)')
        await page.click('.vh-100 > .quote-step > .cust > .text-center > .btn:nth-child(4)')

    });

    it("Validate Generate proposal Document ", async () => {

        await page.waitForSelector('.toast.shown', { hidden: true });

        await page.waitForSelector('.vh-100 > .quote-step > .cust > .text-center > .btn:nth-child(4)', { timeout: 120000 })
        await page.click('.vh-100 > .quote-step > .cust > .text-center > .btn:nth-child(4)')

        await page.screenshot({ path: './Screenshots/HOAGlQuoteNumber.png' });

        await page.waitForSelector('.toast.shown', { hidden: true });

        await page.waitForSelector('.toast.shown', { hidden: true });

        await page.waitForSelector('.toast.shown', { hidden: true });

        await page.waitForSelector('#proposal___BV_modal_content_ > #proposal___BV_modal_body_ > .d-flex > div > .btn:nth-child(2)', { timeout: 120000 })
        await page.click('#proposal___BV_modal_content_ > #proposal___BV_modal_body_ > .d-flex > div > .btn:nth-child(2)')

        await page.waitForSelector('.toast.shown', { hidden: true });

        await page.waitForSelector('#proposal___BV_modal_content_ > #proposal___BV_modal_body_ > .d-flex > div > .btn:nth-child(4)', { timeout: 120000 })
        await page.click('#proposal___BV_modal_content_ > #proposal___BV_modal_body_ > .d-flex > div > .btn:nth-child(4)')

    });

    it("Validate Procceed to bind ", async () => {

        await page.waitForSelector('.modal-content', { hidden: true });

        await page.waitForSelector('.quote-step > .cust > .text-center > a > .btn')
        await page.click('.quote-step > .cust > .text-center > a > .btn')

        await page.waitForSelector('.h-100 > div > div > .custom-control > .custom-control-input')
        await page.click('.h-100 > div > div > .custom-control > .custom-control-input')

        await page.waitForSelector('.h-100 #bindQuote\\.printedName')
        await page.type('.h-100 #bindQuote\\.printedName', 'Puppeteer')

        await page.waitForSelector('.d-flex > .p-3 > .text-left > span > .btn')
        await page.click('.d-flex > .p-3 > .text-left > span > .btn')

        await page.waitForSelector('div > .drop-zone > .text-center > label > a')
        await page.click('div > .drop-zone > .text-center > label > a')

        await page.waitForSelector('input[id^="bindQuote"][id$="description"]', { timeout: 120000 })
        await page.type('input[id^="bindQuote"][id$="description"]', "Puppeteer");

        await page.waitForSelector('.modal-dialog > #bindQuoteAttachments___BV_modal_content_ > #bindQuoteAttachments___BV_modal_footer_ > .w-100 > .btn-primary', { timeout: 120000 })
        await page.click('.modal-dialog > #bindQuoteAttachments___BV_modal_content_ > #bindQuoteAttachments___BV_modal_footer_ > .w-100 > .btn-primary')

        await page.waitForSelector('.modal-open', { hidden: true });

    });

    it("Validate Bind And Generate Policy", async () => {

        await page.waitForSelector('.vh-100 > .quote-step > .quote-bind > .text-center > .btn:nth-child(2)', { timeout: 120000 })
        await page.click('.vh-100 > .quote-step > .quote-bind > .text-center > .btn:nth-child(2)')

        await page.waitForSelector('.modal-open', { hidden: true, timeout: 120000 });

        await page.waitForSelector('.quote-step > div > .d-flex > .detail > .mb-5:nth-child(2)')
        await page.click('.quote-step > div > .d-flex > .detail > .mb-5:nth-child(2)')

        const text = await page.$eval('h2', element => element.textContent)
        console.log('Policy Number : ' + text)

        await page.screenshot({ path: './Screenshots/HOAGlPolicyissue.png' });

    });



})

after(function () {
    // browser.close();

    global.browser = globalVariables.browser;
    global.expect = globalVariables.expect;
});
